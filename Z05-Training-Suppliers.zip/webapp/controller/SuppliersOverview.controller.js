sap.ui.define([
	"com/surian/suppliers/Z05-Training-Suppliers/controller/base/_BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, Filter, FilterOperator, Sorter) {
	"use strict";
	return Controller.extend("com.surian.suppliers.Z05-Training-Suppliers.controller.SuppliersOverview", {

		onInit: function(){
			// Set private sorter for product name.
			this._oSorter = new Sorter("CompanyName", false);				
		},
		
		onSortProductName: function(oEvent){
			this._oSorter.bDescending = !this._oSorter.bDescending;
			this.getView().byId("SuppliersList").getBinding("items").sort(this._oSorter);
		},
		
		onNavigateToDetail: function(oItem) {
			this.getRouter().navTo("supplierDetail", {
				supplierID: oItem.getSource().getModel().getData(oItem.getSource().getBindingContextPath() + "/SupplierID")
			});
		},
		
		onFilterSuppliers: function(oEvent) {
			var aFilter = [];
			var sQuery = oEvent.getParameter("query");
			if (sQuery) {
				aFilter.push(new Filter("CompanyName", FilterOperator.Contains, sQuery));
			}
			var oBinding = this.getView().byId("SuppliersList").getBinding("items");
			oBinding.filter(aFilter);
		}
		
	});
});