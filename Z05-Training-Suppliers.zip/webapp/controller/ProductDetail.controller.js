sap.ui.define([
	"com/surian/suppliers/Z05-Training-Suppliers/controller/base/_BaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.suppliers.Z05-Training-Suppliers.controller.ProductDetail", {

		onInit: function() {
			// call the base controllers's init function
			Controller.prototype.onInit.apply(this, arguments);
			// Match the current route.
			this.getRouter().getRoute("productDetail").attachMatched(this._onRouteMatched, this);		
		},
		
		_onRouteMatched: function(oEvent){
			var productID = oEvent.getParameter("arguments").productID;
			var oView = this.getView();	
			this.sPath = "/Products("+productID+")";
			oView.bindElement({
				path : this.sPath,
				events : {
					dataRequested: function (oEvent) { 
						oView.setBusy(true); 
					},
					dataReceived: function (oEvent) {
						oView.setBusy(false); 
					}
				}
			});		
		},
		
		onChange: function(oEvent){			
			var sNewProductName = this.getView().byId("newProductName").getValue();
			if (sNewProductName && sNewProductName.trim().length > 0){
				var oModel = this.getModel();
				oModel.setProperty(this.sPath +"/ProductName", sNewProductName);				
				console.log("After setProperty: Model has pending changes:", oModel.hasPendingChanges());
				console.log("Pending changes:", oModel.getPendingChanges());
				
				/**
				var oData = {
					"ProductName": sNewProductName
				}
				
				oModel.setHeaders({
					"Accept": "application/json",
        			"Content-Type": "application/json",
        			"If-Match": "*",
        			"x-http-method": "MERGE"
    			});

				
				oModel.update(this.sPath, oData, {
					success: function( oData, oResponse){
							// Success	
							var i = 1;
					}.bind(this),
					error: function(oError){
							jQuery.sap.log.error("Error updating product");
					}
				});
				**/
				
			}		
		},
		
		onReset: function(oEvent){
			var oModel = this.getModel();
			oModel.resetChanges([this.sPath +"/ProductName"]);			
			console.log("After reset: Model has pending changes:", oModel.hasPendingChanges());
			console.log("Pending changes:", oModel.getPendingChanges());				
		},
		
		onCheck: function(oEvent){
			var oModel = this.getModel();
			var oData = oModel.getData(this.sPath);
			console.log("Model data", oData);
			console.log("Model has pending changes:", oModel.hasPendingChanges());
			console.log("Pending changes:", oModel.getPendingChanges());			
		}

	});

});