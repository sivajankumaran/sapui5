sap.ui.define([
	"com/surian/suppliers/Z05-Training-Suppliers/controller/base/_BaseController",
	"sap/ui/table/SortOrder",
	"sap/ui/model/Sorter",
	"sap/m/MessageToast"
], function(Controller, SortOrder, Sort, MessageToast) {
	"use strict";

	return Controller.extend("com.surian.suppliers.Z05-Training-Suppliers.controller.SuppliersDetail", {

		clearAllSortings: function(oEvent){
			var oTable = this.getView().byId("ProductsTable");
			oTable.getBinding("rows").sort(null);
			var aColumns = oTable.getColumns();
			for (var i=0; i < aColumns.length; i++){
				aColumns[i].setSorted(false);	
			}
		},

		onInit: function() {
			// call the base controllers's init function
			Controller.prototype.onInit.apply(this, arguments);
			// Match the current route.
			this.getRouter().getRoute("supplierDetail").attachMatched(this._onRouteMatched, this);		
		},
		
		_onRouteMatched: function(oEvent){
			var supplierID = oEvent.getParameter("arguments").supplierID;
			var oView = this.getView();	
			
			oView.bindElement({
				path : "/Suppliers("+supplierID+")",
				events : {
					dataRequested: function (oEvent) { 
						oView.setBusy(true); 
					},
					dataReceived: function (oEvent) {
						oView.setBusy(false); 
					}
				}
			});		
		},

		onNavigateToDetail: function(oItem) {
			var iSelectedIndex = this.getView().byId("ProductsTable").getSelectedIndex();
			if (iSelectedIndex !== -1){
				var oBinding = this.getView().byId("ProductsTable").getBinding("rows");
				var sPath = oBinding.aKeys[iSelectedIndex];
				var productId = this.getView().getModel().getProperty("/"+sPath).ProductID;
				this.getRouter().navTo("productDetail", {
					productID: productId
				});
			} else{
				MessageToast.show("Please select an item");
			}
		}		

	});

});