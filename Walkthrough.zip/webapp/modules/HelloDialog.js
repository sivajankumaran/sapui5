sap.ui.define([
	"sap/ui/base/Object"
], function (UI5Object) {
	"use strict";

	return UI5Object.extend("com.surian.Walkthrough.controller.HelloDialog", {

		constructor : function (oView) {
			this._oView = oView;	
		},

		open : function () {
			var oView = this._oView;
			this.oDialog = oView.byId("helloDialog");
			
			// create dialog lazily
			if (!this.oDialog) {
				var oFragmentController = {
					onCloseDialog : function () {
						this.oDialog.close();
					}
				};
				// create dialog via fragment factory
				this.oDialog = sap.ui.xmlfragment(oView.getId(), "com.surian.Walkthrough.view.HelloDialog", oFragmentController);
				
				oFragmentController.oDialog = this.oDialog;
				
				// connect dialog to the root view of this component (models, lifecycle)
				oView.addDependent(this.oDialog);
			}
			
			this.oDialog.open();
		}
	});

});