sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"com/surian/Walkthrough/model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"	
], function(Controller, formatter, Filter, FilterOperator){
	"use strict";
	return Controller.extend("com.surian.Walkthrough.controller.InvoiceList", {
		formatter: formatter,
		
		onFilterInvoices : function (evt) {
			var aFilter = [];
			var sQuery = evt.getParameter("query");
			if (sQuery && sQuery.trim().length > 0) {
				aFilter.push(new Filter("ProductName", FilterOperator.Contains, sQuery));
			}

			// filter binding
			var oList = this.getView().byId("invoiceList");
			var oBinding = oList.getBinding("items");
			oBinding.filter(aFilter);			
		},
		
		onPress: function(evt){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oItem = evt.getSource();
			oRouter.navTo("detail", {
				invoicePath: oItem.getBindingContext("invoice").getPath().substr(1) // Remove '/' in path as its not allowed in URL
			});
		}
		
	});
});