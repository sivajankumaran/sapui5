sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageToast"
], function(Controller, MessageToast){
	"use strict";

	return Controller.extend("com.surian.Walkthrough.controller.HelloPanel", {

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */		
		onInit: function(){
         
		},
		
		// Say Hello
		onShowHello: function(evt){
		
		 var oBundle = this.getView().getModel("i18n-manual").getResourceBundle();
         var sRecipient = this.getView().getModel().getProperty("/recipient/name");
         var sMsg = oBundle.getText("helloMsg", [sRecipient]);			
			
		 MessageToast.show(sMsg);
 
		},
		
		onOpenDialog: function(){
			// Get parent component.
			this.getOwnerComponent().openHelloDialog();	
		}	
		
	});
});