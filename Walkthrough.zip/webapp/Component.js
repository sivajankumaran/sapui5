sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/surian/Walkthrough/model/models",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel",
	"com/surian/Walkthrough/modules/HelloDialog"
], function(UIComponent, Device, models, JSONModel, ResourceModel,HelloDialog) {
	"use strict";

	return UIComponent.extend("com.surian.Walkthrough.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			 /** Example 1 - JSON Model
	           * Create a model with data and set it on the component **/
	         var jsonData = {
	            recipient : {
	               name : "World"
	            }
	         };
	         var jsonModel = new JSONModel(jsonData);
	         this.setModel(jsonModel);
	         
	         /** Example 2 - Resource Model
	          *  Bind the resource bundle i18n to the view with name i18n-manual **/
	         
	         // Create the i18n model on the view
	         var resourceModel = new ResourceModel({
	         	bundleName: "com.surian.Walkthrough.i18n.i18n"
	         });
	         
	         this.setModel(resourceModel, "i18n-manual");			
			
			 // As defined in parameter rootView in the manifest.json file, our root view is com.surian.Walkthrough.view.App. 
			 // From the component, the root view can be retrieved at runtime by accessing the rootControl aggregation.
			 this._helloDialog = new HelloDialog(this.getAggregation("rootControl"));
			
			 // Enable hash-based routing.
			 this.getRouter().initialize();
			
		},
		
		openHelloDialog : function () {
			this._helloDialog.open();
		}
		
	});
});