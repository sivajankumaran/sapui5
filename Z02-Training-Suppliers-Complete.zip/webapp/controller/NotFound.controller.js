sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
   "use strict";
   return Controller.extend("com.surian.suppliers.controller.NotFound", {
	  onNavBack : function (oEvent){
	  		// Navigate to master route and replace hash(true) - No browser history entry.
			sap.ui.core.UIComponent.getRouterFor(this).navTo("master", {}, true);
	  }      
   });
});