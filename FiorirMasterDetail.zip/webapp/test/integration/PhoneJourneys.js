jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/surian/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/surian/test/integration/pages/App",
	"com/surian/test/integration/pages/Browser",
	"com/surian/test/integration/pages/Master",
	"com/surian/test/integration/pages/Detail",
	"com/surian/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.surian.view."
	});

	sap.ui.require([
		"com/surian/test/integration/NavigationJourneyPhone",
		"com/surian/test/integration/NotFoundJourneyPhone",
		"com/surian/test/integration/BusyJourneyPhone"
	], function () {
		QUnit.start();
	});
});