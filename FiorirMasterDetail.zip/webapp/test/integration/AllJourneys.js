jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

// We cannot provide stable mock data out of the template.
// If you introduce mock data, by adding .json files in your webapp/localService/mockdata folder you have to provide the following minimum data:
// * At least 3 BusinessPartnerSet in the list
// * All 3 BusinessPartnerSet have at least one ToContacts

sap.ui.require([
	"sap/ui/test/Opa5",
	"com/surian/test/integration/pages/Common",
	"sap/ui/test/opaQunit",
	"com/surian/test/integration/pages/App",
	"com/surian/test/integration/pages/Browser",
	"com/surian/test/integration/pages/Master",
	"com/surian/test/integration/pages/Detail",
	"com/surian/test/integration/pages/NotFound"
], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.surian.view."
	});

	sap.ui.require([
		"com/surian/test/integration/MasterJourney",
		"com/surian/test/integration/NavigationJourney",
		"com/surian/test/integration/NotFoundJourney",
		"com/surian/test/integration/BusyJourney",
		"com/surian/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});