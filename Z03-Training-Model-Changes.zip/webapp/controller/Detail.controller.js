sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History"
], function(Controller,History) {
	"use strict";

	return Controller.extend("com.surian.suppliers.controller.Detail", {
		onInit:function(){
			// Get the router.
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			// Add event handler that will be triggered when the "detail" route is triggered.
			// Add the scope as the controller.
			oRouter.getRoute("detail").attachPatternMatched(this._onRouteMatched, this);
		},
		_onRouteMatched:function(oEvent){
			// Create object path - In our case, id matches the index.
			var sObjectPath = "/Suppliers/" + oEvent.getParameter("arguments").id;
			// Bind the element to the view.
			this.getView().bindElement({path: sObjectPath});
		},	
		onNavPress: function(oEvent){
			// In our case, both parts of the If statement do the same - go to the master view, but the example
			// shows how you can go back if you have more that one view in the stack.
			if(History.getInstance().getPreviousHash() !== undefined){
				window.history.go(-1);	
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("master");
			}
		}
	});
});