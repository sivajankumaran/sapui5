sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.suppliers.controller.Master", {
		onListPress: function(oEvent){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var oItem = oEvent.getSource();
			oRouter.navTo("detail", {
				id: oItem.getBindingContext().getProperty("id")
			});
		}
	});
});