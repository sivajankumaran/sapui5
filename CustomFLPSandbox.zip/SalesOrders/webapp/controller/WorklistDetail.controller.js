sap.ui.define([
	"com/surian/baseui5SalesOrder/controller/base/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/core/routing/History"	
], function(Controller, Filter, FilterOperator, History) {
	"use strict";

	return Controller.extend("com.surian.baseui5SalesOrder.controller.WorklistDetail", {

		onInit: function() {
			Controller.prototype.onInit.apply(this, arguments);
			// Match the current route.
			this.getRouter().getRoute("Detail").attachMatched(this._onRouteMatched, this);		
		},
		
		_onRouteMatched: function(oEvent){

			var supplierID = oEvent.getParameter("arguments").salesOrderId;
			var oView = this.getView();	
			
			oView.bindElement({
				path : "/SalesOrderSet('" + supplierID + "')",
				events : {
					dataRequested: function (oEvent) { 
						oView.setBusy(true); 
					},
					dataReceived: function (oEvent) {
						oView.setBusy(false); 
					}
				}
			});				
			
		},

		onNavBack: function(oEvent) {
			var sPreviousHash = History.getInstance().getPreviousHash();
			if (sPreviousHash !== undefined) {
				window.history.go(-1);
			} else {
				this.getRouter().navTo("Home", {}, true);
			}
		}		

	});
});