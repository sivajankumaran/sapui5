sap.ui.define([
	"com/surian/baseui5SalesOrder/controller/base/BaseController",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator",
	"sap/ui/model/Sorter"
], function(Controller, Filter, FilterOperator, Sorter) {
	"use strict";

	return Controller.extend("com.surian.baseui5SalesOrder.controller.Worklist", {

		onInit: function() {
			Controller.prototype.onInit.apply(this, arguments);
		},

		/* Add table count to header text count once updated */
		onWorklistTableUpdateFinished: function(oEvent) {
			var oTitle = this.getView().byId("worklistTableTitle");
			var oTable = this.getView().byId("worklistTable");
			// Only if remote $count is supported by OData service
			if (oTable.getBinding("items").isLengthFinal()) {
				var iNumberOfEntries = oEvent.getParameter("total");
				var iItems = oTable.getItems().length;
				oTitle.setText(this.getResourceBundle().getText("worklistTitle") + " (" + iItems + " / " + iNumberOfEntries + ")");
			}
		},

		/* Perform worklist live change search */
		onWorklistSearch: function(oEvent) {
			var sSearchValue = oEvent.getSource().getValue();
			var aFilters = [];
			if (sSearchValue && sSearchValue.length > 0) {

				// Create Sales Order Filter.
				var oFilterSalesOrderID = new Filter("SalesOrderID", FilterOperator.Contains, sSearchValue);
				// Create Customer Name Filter
				var oFilterCustomerName = new Filter("CustomerName", FilterOperator.Contains, sSearchValue);

				// Create Combined 'Or' Filter
				var oOrCombinedFilter = new Filter({
					filters: [oFilterSalesOrderID, oFilterCustomerName],
					And: false
				});

				aFilters.push(oOrCombinedFilter);

			}

			// Apply filter to binding
			var oTable = this.getView().byId("worklistTable");
			oTable.getBinding("items").filter(aFilters);
		},

		/* Sort by Customer Name */
		onSortCustomerName: function(oEvent) {

			if (!this._oSorter) {
				this._oSorter = new Sorter("CustomerName", false);
			}

			this._oSorter.bDescending = !this._oSorter.bDescending;
			this.getView().byId("worklistTable").getBinding("items").sort(this._oSorter);
		},

		/* Navigate to the detail view */
		onPress: function(oItem) {
			this.getRouter().navTo("Detail", {
				salesOrderId: oItem.getSource().getModel().getData(oItem.getSource().getBindingContextPath() + "/SalesOrderID")
			});
		},

		/* Perfrom cross application navigation */
		onCustomerPressed: function(oEvent) {
			// Get selected id.
			var id = oEvent.getSource().data().id;
			var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
			if (oCrossAppNavigator && id) {
				oCrossAppNavigator.toExternal({
					target: {
						semanticObject: "BusinessPartners",
						action: "display"
					},
					params: {
						BusinessPartner: id
					}
				});
			}
		}

	});
});