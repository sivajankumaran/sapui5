sap.ui.define([
	"com/surian/baseui5/controller/base/BaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.baseui5.controller.BusinessPartnerNotFoundPage", {

	});
});