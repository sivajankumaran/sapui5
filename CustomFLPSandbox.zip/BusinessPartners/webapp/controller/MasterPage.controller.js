sap.ui.define([
	"com/surian/baseui5/controller/base/BaseController",
		"sap/ui/model/Filter",
		"sap/ui/model/FilterOperator"	
], function(Controller, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.surian.baseui5.controller.MasterPage", {

		onInit: function() {
			Controller.prototype.onInit.apply(this, arguments);

			// Need this method - when you launch the application view deep links for the first time. 
			// We do two things - Check view has binding - we will use eventDelegate functionality to attach an event to the parent control
			// use dataRequested event to check whether data is available for error reasons.
			var that = this;
			this.oListBindingPromise = new Promise(
				function(resolve, reject) {
					that.getView().addEventDelegate({
						onBeforeFirstShow: function() {
							// After binding.
							that.getView().byId("MasterList").getBinding("items").attachEventOnce("dataReceived", function(oEvent) {
								// Check for data
								if (oEvent.getParameter("data")) {
									resolve();
								} else {
									reject();
								}
							}, this);
						}.bind(that)
					});
				}
			);

			// Add route to handle router going to detail page (via deep links)
			this.getRouter().getRoute("detail").attachMatched(this._onDetailRouteMatched, this);

			// Add route to handle router going into the master page - in this scenario we want to select the first item when no route is provided (intiial load).
			this.getRouter().getRoute("master").attachMatched(this._onMasterRouteMatched, this);

			// To handle invalid URLs that do not match a route.
			this.getRouter().attachEvent("bypassed", function(){
				this.getView().byId("MasterList").removeSelections(true);
			}.bind(this));

		},

		/* Route matched - Detail*/
		_onMasterRouteMatched: function(oEvent) {

			// Do not navigate to detail screen on mobile when no route is specified, keep on master.
			if (this.getModel("device").getProperty("/browser/mobile")) {
				return;
			}

			// Empty route pattern, we want to select first item.
			var that = this;
			this.oListBindingPromise.then(function() {
				
				var businessPartnerId = "";
				var aBusinessPartner = this.getOwnerComponent().getComponentData().startupParameters.BusinessPartner;
				
				if (aBusinessPartner && aBusinessPartner.length>0){
					businessPartnerId = aBusinessPartner[0];	
				} else {
					var oList = this.getView().byId("MasterList");
					var oItems = oList.getItems();
					oList.setSelectedItem(oItems[0]);
					businessPartnerId = oItems[0].getBindingContext().getProperty("BusinessPartnerID");
				}
				
				this.getRouter().navTo("detail", {
					BusinessPartnerID: businessPartnerId
				});
				
			}.bind(that));

		},

		/* Route matched - Detail*/
		_onDetailRouteMatched: function(oEvent) {

			var id = oEvent.getParameter("arguments").BusinessPartnerID;

			var oList = this.getView().byId("MasterList");
			var oSelectedItem = oList.getSelectedItem();

			if (oSelectedItem && oSelectedItem.getBindingContext().getProperty("BusinessPartnerID") === id) {
				// User selects an item manually by clicking on an item.
				return;
			} else if (!oSelectedItem) {
				// Deep link - We select an item once the binding has been resolved.
				this.oListBindingPromise.then(function() {
					this._selectAnItem(id);
				}.bind(this));
			} else {
				// Manual has change - select item straight away.
				this._selectAnItem(id);
			}

		},

		/* Select an item - manually */
		_selectAnItem: function(sBusinessPartnerID) {
			var sObjectPath = this.getView().getModel().createKey("BusinessPartnerSet", {
				BusinessPartnerID: sBusinessPartnerID
			});

			var oList = this.getView().byId("MasterList");
			var aItems = this.getView().byId("MasterList").getItems();

			for (var i = 0; i < aItems.length; i++) {
				var oItem = aItems[i];
				if (oItem && oItem.getBindingContext() && oItem.getBindingContext().getPath() === "/" + sObjectPath) {
					oList.setSelectedItem(oItem);
					break;
				}
			}
		},

		/* Navigate to detail view on item press */
		onItemPressed: function(oEvent) {
			// Handle event triggered from list or from the item.
			var oItem = oEvent.getParameter("listItem") || oEvent.getSource();
			var sId = oItem.getBindingContext().getProperty("BusinessPartnerID");
			this.getRouter().navTo("detail", {
				BusinessPartnerID: sId
			}, false);
		},

		/* Search or refresh on Master page performed */
		onSearch: function(oEvent) {
			// Refresh pressed
			if (oEvent.getParameters().refreshButtonPressed) {
				this.onRefresh();
				return;
			}

			var sSearchValue = oEvent.getParameter("query");

			var aFilters = [];
			if (sSearchValue && sSearchValue.length > 0){
				
				// Create Sales Order Filter.
				var oFilterCompanyName = new Filter("CompanyName", FilterOperator.Contains, sSearchValue);
				// Create Customer Name Filter
				var oFilterWebAddress= new Filter("WebAddress", FilterOperator.Contains, sSearchValue);
				
				// Create Combined 'Or' Filter
				var oOrCombinedFilter = new Filter({
					filters: [oFilterCompanyName, oFilterWebAddress],
					And: false
				});
			
				aFilters.push(oOrCombinedFilter);
				
			}

			// Apply filter to binding
			var oList = this.getView().byId("MasterList");
			oList.getBinding("items").filter(aFilters);

		},

		/* Refresh via pull down(touch devices) or refresh button clicked */
		onRefresh: function(oEvent) {
			this.getView().byId("MasterList").getBinding("items").refresh();
		},

		/* Update finished on list */
		onUpdateFinished: function() {
			// hide pull to refresh if necessary
			this.getView().byId("pullToRefresh").hide();
		}

	});
});