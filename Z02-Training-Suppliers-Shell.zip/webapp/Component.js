sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel"
], function(UIComponent, JSONModel, ResourceModel) {
	"use strict";

	return UIComponent.extend("com.surian.suppliers.Component", {

		init: function() {
			// call the parent component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// Create data model.
			var oModel = new JSONModel();
			oModel.loadData("service/data.json");
			this.setModel(oModel);

			// Load i18n resource bundle
			var resourceModel = new ResourceModel({
				bundleName: "com.surian.suppliers.i18n.i18n"
			});

			this.setModel(resourceModel, "i18n");
		},

		createContent: function() {
			// call the parent component's init function
			UIComponent.prototype.createContent.apply(this, arguments);

			// Create Master and Detail Page - XML View
			var oAppView = sap.ui.view("appView", {
				type: sap.ui.core.mvc.ViewType.XML,
				viewName: "com.surian.suppliers.view.App"
			});
			oApp = oAppView.byId("app");
			return oAppView;

		}

	});
});