jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"com/surian/manageproducts/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"com/surian/manageproducts/test/integration/pages/Worklist",
		"com/surian/manageproducts/test/integration/pages/Object",
		"com/surian/manageproducts/test/integration/pages/NotFound",
		"com/surian/manageproducts/test/integration/pages/Browser",
		"com/surian/manageproducts/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "com.surian.manageproducts.view."
	});

	sap.ui.require([
		"com/surian/manageproducts/test/integration/WorklistJourney",
		"com/surian/manageproducts/test/integration/ObjectJourney",
		"com/surian/manageproducts/test/integration/NavigationJourney",
		"com/surian/manageproducts/test/integration/NotFoundJourney",
		"com/surian/manageproducts/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});