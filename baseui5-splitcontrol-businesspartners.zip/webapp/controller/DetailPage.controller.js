sap.ui.define([
	"com/surian/baseui5/controller/base/BaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.baseui5.controller.DetailPage", {

		onInit: function() {
			Controller.prototype.onInit.apply(this, arguments);
			this.getRouter().getRoute("detail").attachMatched(this._onRouteMatched, this);
		},

		_onRouteMatched: function(oEvent) {
			var id = oEvent.getParameter("arguments").BusinessPartnerID;
			var oView = this.getView();

			this.getView().getModel().metadataLoaded().then(function() {
				
				var sObjectPath = this.getView().getModel().createKey("BusinessPartnerSet", {
					BusinessPartnerID: id
				});

				oView.bindElement({
					path: "/" + sObjectPath,
					events: {
						dataRequested: function(oEvent) {
							oView.setBusy(true);
						},
						dataReceived: function(oEvent) {
							oView.setBusy(false);
						}
					}
				});

			}.bind(this));

		}

	});
});