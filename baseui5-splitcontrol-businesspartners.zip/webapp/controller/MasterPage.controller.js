sap.ui.define([
	"com/surian/baseui5/controller/base/BaseController"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.baseui5.controller.MasterPage", {

		onInit: function() {
			Controller.prototype.onInit.apply(this, arguments);
		},
		
		onItemPressed: function(oEvent){
			var oItem = oEvent.getParameter("listItem");
			var sId = oItem.getBindingContext().getProperty("BusinessPartnerID");
			this.getRouter().navTo("detail", {
				BusinessPartnerID: sId	
			}, false);
		}

	});
});