sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.suppliers.controller.Detail", {
		onInit:function(){
		},
		onNavPress: function(oEvent){
			oApp.back();
		}
	});
});