sap.ui.jsview("com.surian.suppliers.view.Detail", {
	getControllerName: function(){
		return "com.surian.suppliers.controller.Detail";
	},
	createContent: function(oController){
		
	  // Create object header
	  var oObjectHeader = new sap.m.ObjectHeader({
	  	title:"{name}",
	  	number: "ID: {id}",
	  	attributes: [ new sap.m.ObjectAttribute({text:"{address/city}"})]
	  });
	  
	  // Create Page
	  var oPageMaster = new sap.m.Page({
	  		title: "Supplier Detail",
	  		showNavButton:true,
	  		navButtonPress: [oController.onNavPress, oController],
	  		content: [oObjectHeader]
	  });
	  	
      return oPageMaster;
	}
});