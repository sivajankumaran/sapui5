sap.ui.jsview("com.surian.suppliers.view.Master", {
	getControllerName: function(){
		return "com.surian.suppliers.controller.Master";
	},
	createContent: function(oController){
		
	  // Create columns headings.
	  var aColumns = [ new sap.m.Column({header: new sap.m.Text({text: "{i18n>ID}"})}),
					   new sap.m.Column({header: new sap.m.Text({text: "{i18n>tableDescriptionTitle}"})})];
	
	  // Create column list items
	  var oColumnItems = new sap.m.ColumnListItem({
		type: "Navigation",
		press: [oController.onListPress, oController],
		cells: [ new sap.m.ObjectIdentifier({text: "{id}"}),
			     new sap.m.ObjectIdentifier({text: "{name}"})]});
		
	  // Create table toolbar	
	  var oTableHeader = new sap.m.Toolbar({
	  	content: [new sap.m.Title({text: "Number of Suppliers: {/CountSuppliers}"})]
	  });
	  
	  // Create the table.
	  var oTable = new sap.m.Table({
	  	columns: aColumns,
	  	headerToolbar: oTableHeader
	  });
	  
	  // Bind the table items to the /Suppliers entries.
	  oTable.bindItems("/Suppliers", oColumnItems);
	  
	  // Create Page
	  var oPageMaster = new sap.m.Page({
	  		title: "Supplier Overview",
	  		content: [oTable]
	  });
	  	
      return oPageMaster;
	}
});