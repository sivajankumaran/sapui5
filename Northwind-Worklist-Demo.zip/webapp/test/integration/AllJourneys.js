jQuery.sap.require("sap.ui.qunit.qunit-css");
jQuery.sap.require("sap.ui.thirdparty.qunit");
jQuery.sap.require("sap.ui.qunit.qunit-junit");
QUnit.config.autostart = false;

sap.ui.require([
		"sap/ui/test/Opa5",
		"con/surian/test/integration/pages/Common",
		"sap/ui/test/opaQunit",
		"con/surian/test/integration/pages/Worklist",
		"con/surian/test/integration/pages/Object",
		"con/surian/test/integration/pages/NotFound",
		"con/surian/test/integration/pages/Browser",
		"con/surian/test/integration/pages/App"
	], function (Opa5, Common) {
	"use strict";
	Opa5.extendConfig({
		arrangements: new Common(),
		viewNamespace: "con.surian.view."
	});

	sap.ui.require([
		"con/surian/test/integration/WorklistJourney",
		"con/surian/test/integration/ObjectJourney",
		"con/surian/test/integration/NavigationJourney",
		"con/surian/test/integration/NotFoundJourney",
		"con/surian/test/integration/FLPIntegrationJourney"
	], function () {
		QUnit.start();
	});
});