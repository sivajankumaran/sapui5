sap.ui.define([
		"con/surian/controller/BaseController"
	], function (BaseController) {
		"use strict";

		return BaseController.extend("con.surian.controller.NotFound", {

			/**
			 * Navigates to the worklist when the link is pressed
			 * @public
			 */
			onLinkPressed : function () {
				this.getRouter().navTo("worklist");
			}

		});

	}
);