sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.suppliers.controller.Master", {
		onInit:function(){
		},
		onListPress: function(oEvent){
			oApp.to(oApp.getPages()[1]);
			var oPage = oApp.getPages()[1];
			var oContext = oEvent.getSource().getBindingContext();
			oPage.setBindingContext(oContext);
		}
	});
});