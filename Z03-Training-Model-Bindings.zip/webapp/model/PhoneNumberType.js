sap.ui.define([
    "sap/ui/model/SimpleType",
    "sap/ui/model/ValidateException"
], function (SimpleType, ValidateException) {
    "use strict";

    return SimpleType.extend("com.surian.suppliers.model.PhoneNumberType", {

        formatValue: function(oValue) {
            return oValue;
        },
        parseValue: function(oValue) {
			return oValue;
	    },
        validateValue: function(oValue) {
        	
        	// Check whether the telephone number is in UK format.
			const regex = /^\(?(?:(?:0(?:0|11)\)?[\s-]?\(?|\+)44\)?[\s-]?\(?(?:0\)?[\s-]?\(?)?|0)(?:\d{2}\)?[\s-]?\d{4}[\s-]?\d{4}|\d{3}\)?[\s-]?\d{3}[\s-]?\d{3,4}|\d{4}\)?[\s-]?(?:\d{5}|\d{3}[\s-]?\d{3})|\d{5}\)?[\s-]?\d{4,5}|8(?:00[\s-]?11[\s-]?11|45[\s-]?46[\s-]?4\d))(?:(?:[\s-]?(?:x|ext\.?\s?|\#)\d+)?)$/g;
			var m;
			var found = false;
			while ((m = regex.exec(oValue)) !== null) {
			    // This is necessary to avoid infinite loops with zero-width matches
			    if (m.index === regex.lastIndex) {
			        regex.lastIndex++;
			    }
			    
			    // The result can be accessed through the `m`-variable.
			    m.forEach((match, groupIndex) => {
			        found = true;
			    });
			}        	
    		if (!found){
            	throw new ValidateException("This is not a valid telephone number");    			
    		}
        }
        
    });

});