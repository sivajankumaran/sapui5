sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/surian/Routing/model/models",
	"sap/ui/model/json/JSONModel"	
], function(UIComponent, Device, models, JSONModel) {
	"use strict";

	return UIComponent.extend("com.surian.Routing.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			// initialise router.
			this.getRouter().initialize(); 
			
			// Creat employee Model
			var oModel = new JSONModel({Employees: [{id: "1001", firstName: "Harry", lastName: "Hawk", address: "Flat 346 Latymer Court", city: "London", postCode: "W6 7LH",
													 resume: {
														information: "Information about Harry Hawk",
														projects: "Projects that Harry Hawk has worked on",
														hobbies: "What does Harry Hawk like to do",
														notes: "Notes about Harry"
													 }},
													{id: "95", firstName: "Jana", lastName: "Kumaran", address: "60 Gastein Road", city: "London", postCode: "W6 8LU",
													resume: {
														information: "Information about JK",
														projects: "Projects that JK has worked on",
														hobbies: "What does JK like to do",
														notes: "Notes about JK"
													 }},
													{id: "45", firstName: "Alan", lastName: "Shearer", address: "37 The Glade", city: "Woodford Green", postCode: "IG8 0QA",
																										 resume: {
														information: "Information about Alan Shearer",
														projects: "Projects that Alan Shearer has worked on",
														hobbies: "What does Alan Shearer like to do",
														notes: "Notes about Alan"
													 }}]});			
			
			this.setModel(oModel, "employees");
		}
	});
});