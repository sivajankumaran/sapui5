sap.ui.define([
	"com/surian/Routing/controller/base/_BaseController"
], function(_BaseController) {
	"use strict";
	return _BaseController.extend("com.surian.Routing.controller.EmployeeDetail", {
		
		onInit: function(){
			this.getRouter().getRoute("employeeDetail").attachMatched(this._onRouteMatched, this);	
		},

		_onRouteMatched : function (oEvent) {
			var oArgs = oEvent.getParameter("arguments");
			var oView = this.getView();
			
			var collection = oView.getModel("employees").getData().Employees;
			var index = $.inArray(oArgs.id, $.map(collection, function(element){
				 return element.id;
			}));
			
			this.employeeId = oArgs.id;
			
			oView.bindElement({
				path : "/Employees/"+index,
				model: "employees",
				events : {
					dataRequested: function (oEvent) { // Only triggered if its a remote call
						oView.setBusy(true); 
					},
					dataReceived: function (oEvent) { // Only triggered if its a remote call
						oView.setBusy(false); 
					}
				},
				change: this._onBindingChange.bind(this)
			});
		},
		
		_onBindingChange : function (oEvent) {
			// No data for the binding
			if (!this.getView().getBindingContext()) {
				this.getRouter().getTargets().display("notFound");
			}
		},
		
		onShowResume : function (oEvent) {
			this.getRouter().navTo("employeeResume", {
				id : this.employeeId
			});
		}		
		
	});
});