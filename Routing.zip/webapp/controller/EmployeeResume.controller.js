sap.ui.define([
	"com/surian/Routing/controller/base/_BaseController",
	"sap/ui/model/json/JSONModel"
], function (_BaseController, JSONModel) {
	"use strict";
	var _aValidTabKeys = ["Info", "Projects", "Hobbies", "Notes"];
	return _BaseController.extend("com.surian.Routing.controller.EmployeeResume", {
		onInit: function () {
			var oRouter = this.getRouter();
			this.getView().setModel(new JSONModel(), "view");
			oRouter.getRoute("employeeResume").attachMatched(this._onRouteMatched, this);
		},
		_onRouteMatched : function (oEvent) {

			var oArgs = oEvent.getParameter("arguments");
			var oView = this.getView();
			
			var collection = oView.getModel("employees").getData().Employees;
			var index = $.inArray(oArgs.id, $.map(collection, function(element){
				 return element.id;
			}));
			
			this.employeeId = oArgs.id;
			
			oView.bindElement({
				path : "/Employees/"+index,
				model: "employees",
				events : {
					dataRequested: function (oEvent) {
						oView.setBusy(true);
					},
					dataReceived: function (oEvent) {
						oView.setBusy(false);
					}
				}
			});
			
			var oQuery = oArgs["?query"];
			if (oQuery && _aValidTabKeys.indexOf(oQuery.tab) > -1){
				oView.getModel("view").setProperty("/selectedTabKey", oQuery.tab);
				
				// Support lazy loading of notes tab.
				if (oQuery.tab === "Notes"){
					// the target is either "resumeTabHobbies" or "resumeTabNotes"
					this.getRouter().getTargets().display("resumeTabNotes");
				}				
				
				
			} else {
				// the default query param should be visible at all time
				this.getRouter().navTo("employeeResume", {
					id : this.employeeId,
					query: {
						tab : _aValidTabKeys[0]
					}
				},true /*no history*/);
			}			
			
			
		},
		
		onTabSelect : function (oEvent){
			this.getRouter().navTo("employeeResume", {
				id : this.employeeId,
				query: {
					tab : oEvent.getParameter("selectedKey")
				}
			}, true /*without history*/);
		}		
	});
});