sap.ui.define([
	"com/surian/Routing/controller/base/_BaseController"
], function (BaseController) {
	"use strict";
	return BaseController.extend("com.surian.Routing.controller.EmployeeList", {
		onListItemPressed : function(oEvent){
			var oItem = oEvent.getSource();
			var element = this.oView.getModel("employees").getProperty(oItem.getBindingContextPath());
			this.getRouter().navTo("employeeDetail",{
				id : element.id
			});
		}
	});
});
