sap.ui.define([
	"com/surian/Routing/controller/base/_BaseController"
], function(_BaseController) {
	"use strict";
	return _BaseController.extend("com.surian.Routing.controller.Overview", {
		onDisplayNotFound : function (oEvent) {
			//display the "notFound" target without changing the hash - however since we havent gone through a route the back button
			// will not work from the not found page.
			// this.getRouter().getTargets().display("notFound");
			
			// Allow back button to work by passing in source target
			this.getRouter().getTargets().display("notFound", {
				fromTarget: "overview"
			});			
		},

		onNavToEmployees : function (oEvent){
			this.getRouter().navTo("EmployeeList"); 
		}
		
	});
});