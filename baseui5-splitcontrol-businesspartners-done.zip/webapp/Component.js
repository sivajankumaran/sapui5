sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/surian/baseui5/model/models",
	"sap/m/MessageBox"	
], function(UIComponent, Device, models, MessageBox) {
	"use strict";

	return UIComponent.extend("com.surian.baseui5.Component", {
		_messageOpen:false,
		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			// create the views based on the url/hash
			this.getRouter().initialize();	
			
			// Handle OData metadata errors.
			this.getModel().attachMetadataFailed(function(oEvent){				
				// Get response and show error.
				var response = oEvent.getParameters();
				this._showServiceError("Metadata service failed - "+response.message + " (" + response.statusCode + " - " + response.statusText +")");
				this.getRouter().getTargets().display("notFound");
			}.bind(this));
			
			// Handle OData service errors.
			this.getModel().attachRequestFailed(function(oEvent){
				var response = oEvent.getParameters();
				if (response.statusCode !== "404" && response.statusCode !== "400"){
					this._showServiceError("Request - "+response.message + " (" + response.statusCode + " - " + response.statusText +")");
					this.getRouter().getTargets().display("notFound");
				}
			}.bind(this));			
			
		},
		
		_showServiceError: function(sDetails){

			if (this._messageOpen){
				// Message dialog open so return.
				return;	
			} else {
				// Create new message dialog
				this._messageOpen = true;
				MessageBox.error("An Error Occurred", {
					details:sDetails,
					actions:[MessageBox.Action.CLOSE],
					onClose: function(){
						this._messageOpen = false;
					}.bind(this)
				});
			}
		}
		
	});
});