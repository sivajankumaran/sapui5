sap.ui.define([
	"com/surian/smartcontrols/table/table/controller/BaseController"
], function(BaseController) {
	"use strict";

	return BaseController.extend("com.surian.smartcontrols.table.table.controller.Master", {
		
	});

});