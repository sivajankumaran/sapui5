sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/model/json/JSONModel",
	"sap/ui/model/resource/ResourceModel"
], function(UIComponent, JSONModel, ResourceModel) {
	"use strict";

	return UIComponent.extend("com.surian.suppliers.Component", {
		
		metadata: {
			manifest: "json",
			handleValidation:true
		},
		
		init: function() {
			// call the parent component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set up router
			this.getRouter().initialize();
			
			// Create model - manually
			var oModel = new JSONModel();
			oModel.attachRequestCompleted(function(oEvent){
				if (oEvent.mParameters.success){
					this.getProperty("/Suppliers").map(function(oSupplier, index) {
						if (index === 1){
							oSupplier.name = oSupplier.name + ' New';
						}
						
						// Convert date.
						oSupplier.invoiceDate = new Date(oSupplier.invoiceDate.substr(0,4), oSupplier.invoiceDate.substr(4,2) - 1, oSupplier.invoiceDate.substr(6,2));
						
					});
					// Update table by refreshing model
					this.refresh(true);
				}	
			});
			oModel.loadData(this.getMetadata().getManifest()["sap.app"].dataSources.mainService.uri);
			this.setModel(oModel);
			
		}

	});
});