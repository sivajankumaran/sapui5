sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/routing/History",
	"com/surian/suppliers/model/PhoneNumberType",
	"com/surian/suppliers/model/formatter"	
], function(Controller, History, PhoneNumberType, formatter) {
	"use strict";

	return Controller.extend("com.surian.suppliers.controller.Detail", {
		_oMessages:{},
		formatter: formatter,
		onInit:function(){
			// Get the router.
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			
			// Add event handler that will be triggered when the "detail" route is triggered.
			// Add the scope as the controller.
			oRouter.getRoute("detail").attachPatternMatched(this._onRouteMatched, this);
			
			// Attach number range validation success, error and parsing.
			this.getView().attachValidationSuccess(this.onValidationSuccess, this);
    		this.getView().attachValidationError(this.onValidationError, this);
			this.getView().attachParseError(this.onParseError, this);
			
		},
		
		_onRouteMatched:function(oEvent){
			// Create object path - In our case, id matches the index.
			var sObjectPath = "/Suppliers/" + oEvent.getParameter("arguments").id;
			// Bind the element to the view.
			this.getView().bindElement({path: sObjectPath});
		},	
		onNavPress: function(oEvent){
			// In our case, both parts of the If statement do the same - go to the master view, but the example
			// shows how you can go back if you have more that one view in the stack.
			if(History.getInstance().getPreviousHash() !== undefined){
				window.history.go(-1);	
			} else {
				var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
				oRouter.navTo("master");
			}
		},
		
		onValidationSuccess: function(oEvent){
			jQuery.sap.log.info("validation success");
			if (this.getView().byId("employees") === oEvent.getSource()){
				sap.ui.getCore().getMessageManager().removeMessages(this._oMessages.employees);
			}
		},
		
		onValidationError: function(oEvent){
			jQuery.sap.log.info("validation error - " + oEvent.getParameters().newValue + "is not between minimum and maximum");
		},
		
		onParseError: function(oEvent){
	
			if (this.getView().byId("employees") === oEvent.getSource()){
				
				if (this._oMessages.employees){
					sap.ui.getCore().getMessageManager().removeMessages(this._oMessages.employees);
				}
				
				var oMessage = 	new sap.ui.core.message.Message({
						message: "Please enter a valid number of employees",
						type: sap.ui.core.MessageType.Error,
						target: oEvent.getSource().getBindingContext().sPath+"/employees",
						processor: this.oView.getModel()
				});
				this._oMessages.employees = oMessage;
				sap.ui.getCore().getMessageManager().addMessages(oMessage);							
			}			
			
			jQuery.sap.log.error("Parse Error occurred - this is no integer", oEvent.getParameters().newValue);	
		},
		
		toUpperCase: function(sName){
			return sName && sName.toUpperCase();
		}
		
	});
});