sap.ui.define([],function(){
	"use strict";
	
	var formatter = {};
	
	formatter.toUpperCase = function(sName){
		return sName && sName.toUpperCase();	
	};
	
	return formatter;
});