sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox",
	"sap/m/MessageToast"
], function(Controller, MessageBox, MessageToast) {
	"use strict";

	return Controller.extend("com.surianCodeJam.controller.Detail", {
		
		onInit: function(){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.getRoute("appDetail").attachMatched(this._onRouteMatched, this);
		},
		
		_onRouteMatched: function(oEvent){
			var oArgs, oView;
			oArgs = oEvent.getParameter("arguments");
			oView = this.getView();
			
			oView.bindElement({
				path: "/Products(" + oArgs.productId + ")",
				events: {
					dataRequested: function(oEvent){
						oView.setBusy(true);
					},
					dataReceived: function(oEvent){
						oView.setBusy(false);
					}
				}
			});
			
		},
		
		handleNavButtonPress: function (evt){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("appHome");
		},
		
		handleOrder: function(evt){
			
			debugger;
			
			// Show confirmation dialog.
			var bundle = this.getView().getModel("i18n").getResourceBundle();
			
			MessageBox.confirm(
				bundle.getText("OrderDialogMsg"),
				function(oAction){
					if (MessageBox.Action.OK === oAction){
						var successMessage = bundle.getText("OrderDialogSuccessMsg");
						
						// Update service and model
						
						// Show success message
						MessageToast.show(successMessage);
						
					}
				},
				bundle.getText("OrderDialogTitle")
			);
			
		}
	});
});