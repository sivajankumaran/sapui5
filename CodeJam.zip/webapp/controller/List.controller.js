sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surianCodeJam.controller.List", {
		handleListItemPress: function (evt){
			var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			var selectedId = evt.getSource().getBindingContext().getProperty("ProductID");
			
			oRouter.navTo("appDetail", {
				productId: selectedId
			});
		},
		
		handleSearch: function(evt){
			
			// Create model filter
			var filters = [];
			var query = evt.getParameter("query");
			
			if (query && query.trim().length > 0){
				filters.push(
					new sap.ui.model.Filter("ProductName", sap.ui.model.FilterOperator.Contains, query)
				);
			}
			
			// Update list binding
			var list = this.getView().byId("list");
			var binding = list.getBinding("items");
			binding.filter(filters);
		}
		
	});
});