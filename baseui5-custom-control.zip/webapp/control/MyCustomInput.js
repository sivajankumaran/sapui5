sap.ui.define([
	"sap/ui/core/Control",
	"sap/ui/layout/Grid",
	"sap/ui/layout/GridData",
	"sap/m/Input",
	"sap/ui/core/Icon"
], function(Control, Grid, GridData, Input, Icon) {
	"use strict";

	return Control.extend("com.surian.baseui5.control.MyCustomInput", {
		metadata: {
			properties: {
				value: {
					type: "string",
					defaultValue: ""
				},
				iconURI: "string"
			},
			aggregations: {
				_layout: {
					type: "sap.ui.layout.Grid", 
					multiple: false,
					visibility: "hidden"
				}
			}

		},
		init: function() {

			if (Control.prototype.init){
				Control.prototype.init.apply(this, arguments);	
			}
			
			// Create icon field
			this._oIcon = new Icon({
				src: this.getIconURI(),
				layoutData: new GridData({
					span: "L1 M11 S11"
				})				
			});
			this._oIcon.addStyleClass("sapUiSmallMarginBegin");
			// Create input field
			this._oInput = new Input({
				value: this.getValue(),
				layoutData: new GridData({
					span: "L11 M11 S11"
				})
			});
			
			this._oInput.attachChange(function(){
				this._oIcon.toggleStyleClass("sapThemePositiveText", this._oInput.getValue() !== "");
				this.setValue(this._oInput.getValue());
			}.bind(this));
			
			this.setAggregation("_layout",
				new Grid({
					content:[
						this._oIcon,
						this._oInput
					],
					hSpacing: 0,
					vSpacing: 0
				})
			);
			
		},
		
		setValue: function(sValue){
			// Set the property - bSuppressRerendering = "true" tells the framework not to trgigger re-rendering.
			this.setProperty("value", sValue, true);	
			// Re-rendering triggered automatically when value set on input ui control.
			this._oInput.setValue(sValue);	
		},
		
		setIconURI: function(sUri){
			this.setProperty("iconURI", sUri, true);
			this._oIcon.setSrc(sUri);	
		},

		exit: function() {
			
			if (Control.prototype.exit){
				Control.prototype.exit.apply(this, arguments);	
			}
			
			this._oIcon.destroy();
			this._oInput.destroy();			
		},
		
		/**
		renderer: function(oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.addClass("myListItem");
			oRM.writeClasses();
			oRM.write(">");
			oRM.renderControl(oControl.getAggregation("_layout"));
			oRM.write("</div>");
		},
		**/

		renderer: {
			render: function(oRM, oControl) {
				oRM.write("<div");
				oRM.writeControlData(oControl);
				oRM.addClass("myListItem");
				oRM.writeClasses();
				oRM.write(">");
				oRM.renderControl(oControl.getAggregation("_layout"));
				oRM.write("</div>");
			}
		},		
		
		/* Pseudo Event handler */
		onclick: function(oEvent){
			alert('onClick');	
		}
		
	});

});