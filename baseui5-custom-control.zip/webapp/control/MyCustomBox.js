sap.ui.define([
	"sap/ui/core/Control"
], function(Control) {
	"use strict";

	return Control.extend("com.surian.baseui5.control.MyCustomBox", {
		metadata: {
			properties: {
				text: "string"
			}
		},

		renderer: function(oRM, oControl) {
			oRM.write("<div");
			oRM.writeControlData(oControl);
			oRM.writeClasses(); // Support for MyCustomBox.addStyleClass();
			oRM.write(">");
			oRM.write("<div class='myCustomBox'>");
			oRM.write("<H3>");
			oRM.writeEscaped(oControl.getText());
			oRM.write("</H3>");
			oRM.write("</div>");
			oRM.write("</div>");
		}
		
	});

});