sap.ui.define([
	"sap/ui/core/Control"
], function(Control) {
	"use strict";

	return Control.extend("com.surian.baseui5.control.MySimpleSpan", {
		metadata: {
			properties: {
				name: "string"
			}
		},

		renderer: function(oRM, oControl) {
			oRM.write("<span>");
			oRM.write(oControl.getName());
			oRM.write("</span>");
		}
		
	});

});