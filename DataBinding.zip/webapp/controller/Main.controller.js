sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";

	return Controller.extend("com.surian.DataBinding.controller.Main", {
		onInit:function(){
			
			// Get page on view.
			var page = this.getView().byId("page");
			
			// 1 - Text with no binding.
			var textNoBinding = new sap.m.Text({
				width:'100%'
			});
			textNoBinding.setText("Text with no binding");
			page.addContent(textNoBinding);
			
			// 2 - Text with binding from resource bundle.
			var textResourceBundleBinding = new sap.m.Text({
				text: '{i18nNew>resourceBoundText}',
				width: '100%'
			});
			page.addContent(textResourceBundleBinding);

			// 3 - Text from JSON Model
			var jsonResourceBundleBinding = new sap.m.Text({
				text: '{person>/header/description}',
				width: '100%'
			});
			page.addContent(jsonResourceBundleBinding);	
			
			// Add view to message manager.
			sap.ui.getCore().getMessageManager().registerObject(this.getView(), true);
			
		}
	});
});