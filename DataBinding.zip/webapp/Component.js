sap.ui.define([
	"sap/ui/core/UIComponent",
	"sap/ui/Device",
	"com/surian/DataBinding/model/models",
	"sap/ui/model/resource/ResourceModel",
	"sap/ui/model/json/JSONModel"
], function(UIComponent, Device, models, ResourceModel, JSONModel) {
	"use strict";

	return UIComponent.extend("com.surian.DataBinding.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function() {
			// call the base component's init function
			UIComponent.prototype.init.apply(this, arguments);

			// set the device model
			this.setModel(models.createDeviceModel(), "device");
			
			/** Create models ***************************************************************************************************/
			
			// 1. Resource Model (i18n is automatically instantiated by the manufest.json but created with different name for demo)
			var resourceModel = new ResourceModel({
				bundleName: "com.surian.DataBinding.i18n.i18n"
			});
			this.setModel(resourceModel, "i18nNew");
			
			// 2. JSON Model 
			var jsonModel = new JSONModel({
				header:{
					name: "Jana",
					description: "text is coming from JSON Model",
					salary:"60000",
					currencyCode: "EUR"
				},
				address: [
					{
						street: "Gastein Road",
						postcode: "W6 8LU"
					},
					{	
						street: "Hammersmith Road",
						postcoe: "W6 IG8"
					}
				]
			});
			
			this.setModel(jsonModel, "person");
			
		}
	});
});